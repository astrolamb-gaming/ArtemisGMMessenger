/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package artemisgmmessenger;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JToggleButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.SwingUtilities;
import javax.swing.border.EtchedBorder;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author Matthew
 */
public class ArtemisGMMessenger {
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                ArtemisGMMessenger agmm = new ArtemisGMMessenger();
                agmm.setup();
            } 
        });
    }
    
    public ArtemisGMMessenger() {}
    
    public void setup() {
        JFrame frame = new JFrame("Artemis Game Master Comms Console");
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(600,500));

        JPanel panel = new JPanel(new MigLayout("flowy"));
        panel.setVisible(true);
        panel.setPreferredSize(new Dimension(600,500));
        frame.add(panel);

        JTextArea field = new JTextArea();
        field.setVisible(true);
        field.setPreferredSize(new Dimension(15000, 60));
        panel.add(field, "wrap, spanx");
        field.setBorder(new EtchedBorder());


        JToggleButton all = new JToggleButton("All Ships");
        JToggleButton ship1 = new JToggleButton("Ship 1");
        JToggleButton ship2 = new JToggleButton("Ship 2");
        JToggleButton ship3 = new JToggleButton("Ship 3");
        JToggleButton ship4 = new JToggleButton("Ship 4");
        JToggleButton ship5 = new JToggleButton("Ship 5");
        JToggleButton ship6 = new JToggleButton("Ship 6");
        JToggleButton ship7 = new JToggleButton("Ship 7");
        JToggleButton ship8 = new JToggleButton("Ship 8");

        List<JToggleButton> ships = new ArrayList<>();
        ships.add(ship1);
        ships.add(ship2);
        ships.add(ship3);
        ships.add(ship4);
        ships.add(ship5);
        ships.add(ship6);
        ships.add(ship7);
        ships.add(ship8);

        HashMap<JToggleButton, ButtonState> shipStates = new HashMap<>();
        shipStates.put(ship1, new ButtonState(false));
        shipStates.put(ship2, new ButtonState(false));
        shipStates.put(ship3, new ButtonState(false));
        shipStates.put(ship4, new ButtonState(false));
        shipStates.put(ship5, new ButtonState(false));
        shipStates.put(ship6, new ButtonState(false));
        shipStates.put(ship7, new ButtonState(false));
        shipStates.put(ship8, new ButtonState(false));

        JToggleButton allConsoles = new JToggleButton("Send to All");
        JToggleButton toScience = new JToggleButton("Send to Science");
        JToggleButton toComms = new JToggleButton("Send to Comms");
        JToggleButton toCaptain = new JToggleButton("Send to Captain's Map");
        JToggleButton toEng = new JToggleButton("Send to Engineering");
        JToggleButton toHelm = new JToggleButton("Send to Helm");
        JToggleButton toWea = new JToggleButton("Send to Weapons");

        HashMap<JToggleButton, ButtonState> consoleStates = new HashMap<>();
        consoleStates.put(toScience, new ButtonState(false));
        consoleStates.put(toComms, new ButtonState(false));
        consoleStates.put(toCaptain, new ButtonState(false));
        consoleStates.put(toEng, new ButtonState(false));
        consoleStates.put(toHelm, new ButtonState(false));
        consoleStates.put(toWea, new ButtonState(false));

        List<JToggleButton> consoles = new ArrayList<>();
        consoles.add(toScience);
        consoles.add(toComms);
        consoles.add(toCaptain);
        consoles.add(toEng);
        consoles.add(toHelm);
        consoles.add(toWea);

        panel.add(all);
        panel.add(ship1);
        panel.add(ship2); 
        panel.add(ship3);
        panel.add(ship4);
        panel.add(ship5);
        panel.add(ship6);
        panel.add(ship7);
        panel.add(ship8, "wrap");
        JPanel spacer = new JPanel();
        spacer.setPreferredSize(new Dimension(50, 10));
        panel.add(spacer, "wrap");
        //panel.add(spacer);
        panel.add(allConsoles);
        panel.add(toScience);
        panel.add(toComms);
        panel.add(toCaptain);
        panel.add(toEng);
        panel.add(toHelm);
        panel.add(toWea);

        JPanel spacer2 = new JPanel();
        spacer2.setPreferredSize(new Dimension(60, 40)); 
        panel.add(spacer2);

        JButton send = new JButton("Send");
        send.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO: Send message code here
                System.out.println("Sending... (Not really)");

                String s = field.getText();
                
                try {
                    byte[] ba = s.getBytes("UTF-16");
                    System.out.println(ba);
                    System.out.println(new String(ba).toCharArray()[0]);
                    
                } catch (UnsupportedEncodingException ex) {
                    
                }

            }
        }); 

        panel.add(send);


        ship1.setVisible(true);
        ship2.setVisible(true);
        ship3.setVisible(true);
        ship4.setVisible(true);
        ship5.setVisible(true);
        ship6.setVisible(true);
        ship7.setVisible(true);
        ship8.setVisible(true);
        toScience.setVisible(true);
        toComms.setVisible(true);
        toCaptain.setVisible(true);
        toEng.setVisible(true);
        toHelm.setVisible(true);
        toWea.setVisible(true);


        all.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println(all.isSelected());
                if (all.isSelected()) {
                    for(JToggleButton j : shipStates.keySet()) {
                        j.setSelected(all.isSelected()); 
                    }
                } else {
                    for (JToggleButton j : shipStates.keySet()) {
                        j.setSelected(shipStates.get(j).bool);
                    }
                }
            }
        });

        allConsoles.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (allConsoles.isSelected()) {
                    for (JToggleButton j : consoleStates.keySet()) {
                        j.setSelected(allConsoles.isSelected());
                    }
                } else {
                    for (JToggleButton j : consoleStates.keySet()) {
                        j.setSelected(consoleStates.get(j).bool);
                    }
                }
            }
        }); 

        for (JToggleButton j : shipStates.keySet()) {
            j.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    shipStates.get(j).bool = j.isSelected();
                }
            }); 
        }


        for (JToggleButton j : consoleStates.keySet()) {
            j.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    consoleStates.get(j).bool = j.isSelected();
                }
            }); 
        }


        frame.pack();
    }
    
    
    class ButtonState {
        
        public boolean bool;
        
        public ButtonState(boolean b) {
            bool = b;
        }
    
    }

}
